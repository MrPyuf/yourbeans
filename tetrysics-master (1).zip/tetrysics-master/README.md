#TETRYSICS

##About
Tetrysics was built for the Plymouth University Hackathon Society's first hackathon. It was made in 7 hours. To install, grab all of the files of the repo and open that folder in Unity 4.0 or above.
